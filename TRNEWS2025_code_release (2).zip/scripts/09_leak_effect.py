"""Effect of near-duplicate leakage on the S1 test scores, at Jaccard thresholds 0.6/0.8/0.9, using the saved test predictions."""
import json, os
import numpy as np, pandas as pd
from sklearn.metrics import f1_score, accuracy_score
CLASSES = ["Magazin", "Siyaset", "Spor", "Kültür-Sanat", "Sağlık", "Finans-Ekonomi", "Bilim-Teknoloji", "Turizm", "Çevre"]
sp = pd.read_parquet("data/splits.parquet")
y = sp.label.map({c: i for i, c in enumerate(CLASSES)}).values
te = (sp.split_orig == "test").values; tr = (sp.split_orig == "train").values
rows = []
for t in (60, 80, 90):
    cl = pd.read_parquet("data/near_dup_clusters.parquet" if t == 80 else f"data/near_dup_clusters_t{t}.parquet")
    c = cl.cluster.values; multi = cl.cluster_size.values > 1
    train_cl = set(c[tr & multi])
    leak = te & multi & np.isin(c, list(train_cl))
    for m in ["MNB_counts", "LinearSVM_tfidf", "fastText", "BiLSTM_GloVe", "BERTurk"]:
        p = f"results/runs/split_orig__{m}_pred.npy"
        if not os.path.exists(p):
            continue
        yp = np.full(len(sp), -1); yp[te] = np.load(p)
        cleanm = te & ~leak
        rows.append(dict(threshold=t / 100, model=m, n_leaked=int(leak.sum()), share_leaked=float(leak.sum() / te.sum()),
                         acc_leaked=accuracy_score(y[leak], yp[leak]), acc_nonleaked=accuracy_score(y[cleanm], yp[cleanm]),
                         macro_f1_all=f1_score(y[te], yp[te], average="macro"), macro_f1_clean=f1_score(y[cleanm], yp[cleanm], average="macro")))
df = pd.DataFrame(rows); df.to_csv("results/leak_effect.csv", index=False)
print(df.round(4).to_string(index=False))
