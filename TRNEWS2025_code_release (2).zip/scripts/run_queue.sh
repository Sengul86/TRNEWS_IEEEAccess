#!/bin/sh
# Restart-safe queue: each job resumes from its checkpoint; finished jobs (result JSON present) are skipped.
cd "$(dirname "$0")/.."
[ -f results/runs/split_orig__BiLSTM_GloVe.json ] || python -I scripts/11_bilstm_cpu.py split_orig ${GLOVE:-glove/vectors.txt} >> results/log_bilstm_s1.txt 2>&1
[ -f results/runs/split_orig__BERTurk.json ] || python -I scripts/12_berturk_cpu.py ${BERTURK_DIR:-dbmdz/bert-base-turkish-uncased} 50000 split_orig >> results/log_berturk_s1.txt 2>&1
[ -f results/runs/split_source_heldout__BiLSTM_GloVe.json ] || python -I scripts/11_bilstm_cpu.py split_source_heldout ${GLOVE:-glove/vectors.txt} >> results/log_bilstm_s3.txt 2>&1
[ -f results/runs/split_dedup_grouped__BiLSTM_GloVe.json ] || python -I scripts/11_bilstm_cpu.py split_dedup_grouped ${GLOVE:-glove/vectors.txt} >> results/log_bilstm_s2.txt 2>&1
echo QUEUE_DONE > results/queue_done.txt
