"""Train and evaluate CPU baselines on a given split.

Usage: python 04_baselines.py <split_column> [models]
  split_column: split_orig | split_dedup_grouped | split_source_heldout
  models: comma-separated subset of  mnb,svm,fasttext  (default: all)

Features: Turkish-aware lower-casing; word uni+bi-grams hashed into 2^21 dimensions (no vocabulary leakage from test).
  MNB  : Multinomial Naive Bayes on hashed counts (alpha=0.01)
  SVM  : Linear SVM (liblinear, one-vs-rest, C=0.5, class_weight='balanced') on sublinear TF-IDF of the hashed counts
  fastText: supervised fastText, dim 100, word bi-grams, 5 epochs, lr 0.5, softmax loss
All models use only the training partition; the validation partition is not used for tuning (fixed settings).
"""
import json, os, re, sys, time, platform, tempfile
import numpy as np, pandas as pd, pyarrow.parquet as pq
from sklearn.feature_extraction.text import HashingVectorizer, TfidfTransformer
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix

col = sys.argv[1]
models = sys.argv[2].split(",") if len(sys.argv) > 2 else ["mnb", "svm", "fasttext"]
CLASSES = ["Magazin", "Siyaset", "Spor", "Kültür-Sanat", "Sağlık", "Finans-Ekonomi", "Bilim-Teknoloji", "Turizm", "Çevre"]
os.makedirs("results/runs", exist_ok=True)

def tr_lower(s):
    return s.replace("I", "ı").replace("İ", "i").lower()

df = pq.read_table("data/trnews.parquet", columns=["id", "text"]).to_pandas()
sp = pd.read_parquet("data/splits.parquet")
assert (sp.id.values == df.id.values).all()
df["label"] = sp.label.values; df["split"] = sp[col].values
df["clean"] = ~sp.s1_test_has_train_near_dup.values
df["text"] = [tr_lower(t) for t in df.text]
y = df.label.map({c: i for i, c in enumerate(CLASSES)}).values
tr = (df.split == "train").values; te = (df.split == "test").values
print(col, "train", tr.sum(), "test", te.sum(), flush=True)

def metrics(yt, yp):
    p, r, f, _ = precision_recall_fscore_support(yt, yp, labels=range(9), zero_division=0)
    P, R, F, _ = precision_recall_fscore_support(yt, yp, labels=range(9), average="macro", zero_division=0)
    return dict(accuracy=accuracy_score(yt, yp), macro_p=P, macro_r=R, macro_f1=F,
                per_class={c: dict(p=float(p[i]), r=float(r[i]), f1=float(f[i]), support=int((yt == i).sum())) for i, c in enumerate(CLASSES)},
                confusion=confusion_matrix(yt, yp, labels=range(9)).tolist())

hw = dict(cpu=platform.processor() or platform.machine(), n_cpu=os.cpu_count(), python=platform.python_version())
def save(name, yp, t_train, t_test):
    res = dict(model=name, split=col, hardware=hw, train_time_s=round(t_train, 1), test_time_s=round(t_test, 2),
               n_train=int(tr.sum()), n_test=int(te.sum()), test=metrics(y[te], yp))
    if col == "split_orig":   # S1 'clean' test: without articles that have a near-duplicate in the training set
        m = df.clean.values[te]
        res["test_clean"] = metrics(y[te][m], yp[m]); res["n_test_clean"] = int(m.sum())
    json.dump(res, open(f"results/runs/{col}__{name}.json", "w"), indent=1)
    np.save(f"results/runs/{col}__{name}_pred.npy", yp.astype(np.int8))
    print(f"{name}: acc {res['test']['accuracy']:.4f} macroF1 {res['test']['macro_f1']:.4f}"
          + (f" | clean macroF1 {res['test_clean']['macro_f1']:.4f}" if "test_clean" in res else "")
          + f" | train {t_train:.0f}s test {t_test:.1f}s", flush=True)

if {"mnb", "svm"} & set(models):
    t0 = time.time()
    hv = HashingVectorizer(ngram_range=(1, 2), n_features=2 ** 21, alternate_sign=False, norm=None,
                           token_pattern=r"(?u)\b\w+\b", dtype=np.float32)
    Xtr = hv.transform(df.text[tr]); t_vec_tr = time.time() - t0
    t1 = time.time(); Xte = hv.transform(df.text[te]); t_vec_te = time.time() - t1
    if "fasttext" not in models:
        df.drop(columns=["text"], inplace=True); import gc; gc.collect()
    print(f"hashing done {Xtr.shape} nnz={Xtr.nnz}", flush=True)
    if "mnb" in models:
        t0 = time.time(); clf = MultinomialNB(alpha=0.01).fit(Xtr, y[tr]); ttr = time.time() - t0 + t_vec_tr
        t0 = time.time(); yp = clf.predict(Xte); tte = time.time() - t0 + t_vec_te
        save("MNB_counts", yp, ttr, tte)
    if "svm" in models:
        t0 = time.time(); tf = TfidfTransformer(sublinear_tf=True).fit(Xtr); Ttr = tf.transform(Xtr, copy=False); del Xtr
        clf = LinearSVC(C=0.5, class_weight="balanced", dual=True, max_iter=2000, random_state=42).fit(Ttr, y[tr])
        ttr = time.time() - t0 + t_vec_tr; del Ttr
        t0 = time.time(); yp = clf.predict(tf.transform(Xte)); tte = time.time() - t0 + t_vec_te
        save("LinearSVM_tfidf", yp, ttr, tte)
    Xtr = None; Xte = None

if "fasttext" in models:
    import fasttext
    clean = lambda s: re.sub(r"\s+", " ", re.sub(r"[^\w\s]", " ", s))
    with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False, encoding="utf-8") as f:
        for t, l in zip(df.text[tr], y[tr]):
            f.write(f"__label__{l} {clean(t)}\n")
        path = f.name
    t0 = time.time()
    m = fasttext.train_supervised(path, dim=100, wordNgrams=2, epoch=5, lr=0.5, minCount=2, loss="softmax", thread=4, seed=42, verbose=0)
    ttr = time.time() - t0; os.remove(path)
    t0 = time.time()
    labs, _ = m.predict([clean(t) for t in df.text[te]], k=1)
    yp = np.array([int(l[0].replace("__label__", "")) for l in labs]); tte = time.time() - t0
    save("fastText", yp, ttr, tte)
