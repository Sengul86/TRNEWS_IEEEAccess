"""Agreement statistics for the label audit sample.

Input : results/label_audit_sheet_for_annotators.csv with the columns 'annotator1' and 'annotator2' filled in
        (one of the nine class names, or 'Belirsiz' for an article that fits no class / several classes equally).
        Optionally a column 'adjudicated' for the final decision on disagreements (otherwise annotator1 is used).
Output: results/label_audit_agreement.json and results/label_audit_confusion.csv
"""
import json, sys
import numpy as np, pandas as pd
from sklearn.metrics import cohen_kappa_score

CLASSES = ["Magazin", "Siyaset", "Spor", "Kültür-Sanat", "Sağlık", "Finans-Ekonomi", "Bilim-Teknoloji", "Turizm", "Çevre"]
sheet = pd.read_csv(sys.argv[1] if len(sys.argv) > 1 else "results/label_audit_sheet_for_annotators.csv")
gold = pd.read_csv("results/label_audit_sample_with_labels.csv")[["id", "dataset_label_hidden_from_annotators"]]
d = sheet.merge(gold, on="id")
for c in ("annotator1", "annotator2"):
    d[c] = d[c].astype(str).str.strip()
    bad = ~d[c].isin(CLASSES + ["Belirsiz"])
    assert not bad.any(), f"unknown labels in {c}: {d.loc[bad, c].unique()[:10]}"
final = d["adjudicated"].astype(str).str.strip() if "adjudicated" in d else d.annotator1.where(d.annotator1 == d.annotator2, d.annotator1)
lab = d.dataset_label_hidden_from_annotators
res = dict(n=int(len(d)),
           kappa_annotators=float(cohen_kappa_score(d.annotator1, d.annotator2)),
           raw_agreement_annotators=float((d.annotator1 == d.annotator2).mean()),
           agreement_with_dataset=float((final == lab).mean()),
           macro_agreement_with_dataset=float(np.mean([(final[lab == c] == c).mean() for c in CLASSES])),
           per_class_agreement={c: float((final[lab == c] == c).mean()) for c in CLASSES},
           undecidable_share=float((final == "Belirsiz").mean()))
pd.crosstab(lab, final).to_csv("results/label_audit_confusion.csv")
json.dump(res, open("results/label_audit_agreement.json", "w"), indent=2, ensure_ascii=False)
print(json.dumps(res, indent=2, ensure_ascii=False))
