"""Controlled cross-dataset comparison: identical models and protocol on TTC-4900 and on size- and balance-matched
samples of TRNEWS-2025.

Protocol: stratified 5-fold cross-validation, macro-F1 and accuracy (mean +- SD over folds, and over 5 random draws for
TRNEWS-2025). Text normalisation is identical for both datasets (Turkish lower-casing, punctuation removal, and
underscore -> space, because the TTC-4900 release joins multi-word named entities with underscores).
Models: MNB on uni+bi-gram counts, Linear SVM on uni+bi-gram TF-IDF (C=0.5), fastText (dim 100, bigrams, 25 epochs).

Conditions
  TTC-4900 (7 classes)                  : all 4,900 articles
  TTC-4900 (6 shared classes)           : without 'dunya' (World), 4,200 articles
  TRNEWS-2025 balanced (6 shared classes): 700 articles per class, 5 random draws
  TRNEWS-2025 balanced (9 classes)       : 700 articles per class, 5 random draws
"""
import json, os, re, sys, tempfile
import numpy as np, pandas as pd, pyarrow.parquet as pq
from sklearn.model_selection import StratifiedKFold
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import LinearSVC
from sklearn.metrics import f1_score, accuracy_score
import fasttext

TTC = sys.argv[1]
TTC_NAMES = {0: "siyaset", 1: "dunya", 2: "ekonomi", 3: "kultur", 4: "saglik", 5: "spor", 6: "teknoloji"}
SHARED_TR = {"Siyaset": "siyaset", "Finans-Ekonomi": "ekonomi", "Kültür-Sanat": "kultur", "Sağlık": "saglik",
             "Spor": "spor", "Bilim-Teknoloji": "teknoloji"}

def norm(s):
    s = s.replace("I", "ı").replace("İ", "i").lower().replace("_", " ")
    return re.sub(r"\s+", " ", re.sub(r"[^\w\s]|\d", " ", s)).strip()

def run_models(texts, y, seed=0):
    out = {m: [] for m in ["MNB", "LinearSVM", "fastText"]}
    skf = StratifiedKFold(5, shuffle=True, random_state=seed)
    for tr, te in skf.split(texts, y):
        Xtr = [texts[i] for i in tr]; Xte = [texts[i] for i in te]
        cv = CountVectorizer(ngram_range=(1, 2), min_df=2, token_pattern=r"(?u)\b\w+\b")
        A = cv.fit_transform(Xtr); B = cv.transform(Xte)
        p = MultinomialNB(alpha=0.1).fit(A, y[tr]).predict(B)
        out["MNB"].append((f1_score(y[te], p, average="macro"), accuracy_score(y[te], p)))
        tv = TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True, token_pattern=r"(?u)\b\w+\b")
        A = tv.fit_transform(Xtr); B = tv.transform(Xte)
        p = LinearSVC(C=0.5, random_state=42).fit(A, y[tr]).predict(B)
        out["LinearSVM"].append((f1_score(y[te], p, average="macro"), accuracy_score(y[te], p)))
        with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False, encoding="utf-8") as f:
            for t, l in zip(Xtr, y[tr]):
                f.write(f"__label__{l} {t}\n")
        m = fasttext.train_supervised(f.name, dim=100, wordNgrams=2, epoch=25, lr=0.5, minCount=1, thread=2, seed=42, verbose=0)
        os.remove(f.name)
        p = np.array([int(l[0].replace("__label__", "")) for l in m.predict(Xte, k=1)[0]])
        out["fastText"].append((f1_score(y[te], p, average="macro"), accuracy_score(y[te], p)))
    return out

results = []
def add(name, out, draw=None):
    for m, v in out.items():
        for k, (f, a) in enumerate(v):
            results.append(dict(condition=name, model=m, draw=draw, fold=k, macro_f1=f, accuracy=a))

ttc = pd.read_parquet(TTC)
ttc["text_n"] = [norm(t) for t in ttc.text]
add("TTC-4900 (7 classes)", run_models(ttc.text_n.tolist(), ttc.category.values))
t6 = ttc[ttc.category != 1]
add("TTC-4900 (6 shared classes)", run_models(t6.text_n.tolist(), t6.category.values))
print("TTC done", flush=True)

tr = pq.read_table("data/trnews.parquet", columns=["text", "label"]).to_pandas()
for draw in range(5):
    rng = np.random.RandomState(100 + draw)
    for name, classes in [("TRNEWS-2025 balanced (6 shared classes)", list(SHARED_TR)),
                          ("TRNEWS-2025 balanced (9 classes)", sorted(tr.label.unique()))]:
        idx = np.concatenate([rng.choice(np.flatnonzero(tr.label.values == c), 700, replace=False) for c in classes])
        sub = tr.iloc[idx]
        y = sub.label.map({c: i for i, c in enumerate(classes)}).values
        add(name, run_models([norm(t) for t in sub.text], y, seed=draw), draw)
    print("draw", draw, "done", flush=True)

res = pd.DataFrame(results)
res.to_csv("results/cross_dataset_folds.csv", index=False)
summ = res.groupby(["condition", "model"]).agg(macro_f1_mean=("macro_f1", "mean"), macro_f1_sd=("macro_f1", "std"),
                                               acc_mean=("accuracy", "mean"), acc_sd=("accuracy", "std"), n=("macro_f1", "size")).reset_index()
summ.to_csv("results/cross_dataset_summary.csv", index=False)
print(summ.to_string(index=False))
