"""Build LaTeX tables and number macros for the revised manuscript from results/*.json / *.csv.
Missing results (e.g. GPU models not yet run) are rendered as a red 'pending' marker."""
import glob, json, os
import numpy as np, pandas as pd

R = "results"; OUT = "manuscript/generated"; os.makedirs(OUT, exist_ok=True)
CLASSES = ["Magazin", "Siyaset", "Spor", "Kültür-Sanat", "Sağlık", "Finans-Ekonomi", "Bilim-Teknoloji", "Turizm", "Çevre"]
EN = {"Magazin": "Magazine", "Siyaset": "Politics", "Spor": "Sports", "Kültür-Sanat": "Arts--Culture", "Sağlık": "Health",
      "Finans-Ekonomi": "Finance--Economy", "Bilim-Teknoloji": "Science--Technology", "Turizm": "Tourism", "Çevre": "Environment"}
MODELS = [("MNB_counts", "MNB (counts)"), ("LinearSVM_tfidf", "Linear SVM (TF-IDF)"), ("fastText", "fastText"),
          ("BiLSTM_GloVe", "BiLSTM--GloVe"), ("BERTurk", "BERTurk$^\\dagger$")]
SPLITS = [("split_orig", "S1"), ("split_dedup_grouped", "S2"), ("split_source_heldout", "S3")]
PEND = r"\pending"
MAC = {}

def mac(k, v):
    k = "".join(ch for ch in k if ch.isalpha())
    MAC[k] = v

def load(split, model):
    p = f"{R}/runs/{split}__{model}.json"
    return json.load(open(p)) if os.path.exists(p) else None

def pct(x, d=1):
    return f"{100*x:.{d}f}"

def write(name, s):
    open(f"{OUT}/{name}.tex", "w").write(s)

# ---------------------------------------------------------------- main results on S1
rows = ""
for m, lbl in MODELS:
    r = load("split_orig", m)
    if r is None:
        rows += f"{lbl} & " + " & ".join([PEND] * 6) + r" \\" + "\n"; continue
    t = r["test"]
    rows += f"{lbl} & {pct(t['accuracy'])} & {pct(t['macro_p'])} & {pct(t['macro_r'])} & {pct(t['macro_f1'])} & {r['train_time_s']:.0f} & {r['test_time_s']:.0f}" + r" \\" + "\n"
    key = "".join(ch for ch in m if ch.isalpha())
    mac(f"Acc{key}", pct(t["accuracy"])); mac(f"MF{key}", pct(t["macro_f1"]))
    mac(f"EnvFOne{key}", pct(t["per_class"]["Çevre"]["f1"]))
write("tab_main", r"""\begin{table*}[t]
\centering
\footnotesize
\caption{Baseline results on the published split (S1) of TRNEWS-2025. Accuracy and macro-averaged precision, recall and F1 (\%) on the held-out test set (80,159 articles). Train and test times are wall-clock seconds on the same 4-core CPU, including feature extraction (Section~\ref{sec:setup}). $^\dagger$BERTurk was fine-tuned on a stratified subset of 50,000 training articles (one epoch, 128 tokens).}
\label{tab:model_comparison}
\begin{tabular}{lrrrrrr}
\toprule
Model & Acc. & Macro-P & Macro-R & Macro-F1 & Train (s) & Test (s) \\
\midrule
""" + rows + r"""\bottomrule
\end{tabular}
\end{table*}
""")

# ---------------------------------------------------------------- class-wise F1 on S1
hdr = " & ".join(lbl for _, lbl in MODELS)
rows = ""
for c in CLASSES:
    cells = []
    for m, _ in MODELS:
        r = load("split_orig", m)
        cells.append(pct(r["test"]["per_class"][c]["f1"]) if r else PEND)
    sup = load("split_orig", "LinearSVM_tfidf")
    rows += f"{EN[c]} & " + " & ".join(cells) + f" & {sup['test']['per_class'][c]['support']:,}" + r" \\" + "\n"
write("tab_classwise", r"""\begin{table*}[t]
\centering
\footnotesize
\caption{Class-wise F1 scores (\%) on the S1 test set.}
\label{tab:classwise}
\resizebox{\textwidth}{!}{%
\begin{tabular}{l""" + "r" * (len(MODELS) + 1) + r"""}
\toprule
Class & """ + hdr + r""" & Support \\
\midrule
""" + rows + r"""\bottomrule
\end{tabular}}
\end{table*}
""")

# ---------------------------------------------------------------- robustness: S1, S1-clean, S2, S3
rows = ""
for m, lbl in MODELS:
    r1, r2, r3 = load("split_orig", m), load("split_dedup_grouped", m), load("split_source_heldout", m)
    NA = "--" if m == "BERTurk" else PEND
    f = lambda r, k="test": pct(r[k]["macro_f1"]) if r else (PEND if (k == "test_clean" or r is r1) else NA)
    a = lambda r: pct(r["test"]["accuracy"]) if r else (PEND if r is r1 else NA)
    d3 = f"{100*(r3['test']['macro_f1']-r1['test']['macro_f1']):+.1f}".replace("-", "$-$").replace("$-$0.0", "0.0").replace("+0.0", "0.0") if (r1 and r3) else NA
    rows += f"{lbl} & {a(r1)} & {f(r1)} & {f(r1,'test_clean')} & {a(r2)} & {f(r2)} & {a(r3)} & {f(r3)} & {d3}" + r" \\" + "\n"
    key = "".join(ch for ch in m if ch.isalpha())
    if r1:
        mac(f"MFclean{key}", f(r1, "test_clean"))
    if r2:
        mac(f"MFdedup{key}", f(r2)); mac(f"Accdedup{key}", a(r2))
    if r3:
        mac(f"MFsrc{key}", f(r3)); mac(f"Accsrc{key}", a(r3)); mac(f"Dsrc{key}", d3)
        mac(f"EnvFOnesrc{key}", pct(r3["test"]["per_class"]["Çevre"]["f1"]))
write("tab_robust", r"""\begin{table*}[t]
\centering
\footnotesize
\caption{Sensitivity of the baselines to the evaluation split (\%). S1: published article-level split; S1-clean: S1 test set without the articles that have a near-duplicate (estimated Jaccard $\geq0.8$) in the S1 training set; S2: near-duplicate clusters kept within one partition; S3: source-held-out split (test publishers never seen in training). $\Delta$: macro-F1 difference S3$-$S1.}
\label{tab:robust}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lrrrrrrrr}
\toprule
 & \multicolumn{3}{c}{S1} & \multicolumn{2}{c}{S2 (dedup-grouped)} & \multicolumn{2}{c}{S3 (source-held-out)} & \\
\cmidrule(lr){2-4}\cmidrule(lr){5-6}\cmidrule(lr){7-8}
Model & Acc. & Macro-F1 & Macro-F1 (clean) & Acc. & Macro-F1 & Acc. & Macro-F1 & $\Delta$ \\
\midrule
""" + rows + r"""\bottomrule
\end{tabular}}
\end{table*}
""")

# class-wise S3 vs S1 for the best CPU model
r1, r3 = load("split_orig", "LinearSVM_tfidf"), load("split_source_heldout", "LinearSVM_tfidf")
if r1 and r3:
    rows = ""
    for c in CLASSES:
        rows += f"{EN[c]} & {pct(r1['test']['per_class'][c]['f1'])} & {pct(r3['test']['per_class'][c]['f1'])} & {r3['test']['per_class'][c]['support']:,}" + r" \\" + "\n"
    write("tab_src_classwise", r"""\begin{table}[t]
\centering
\footnotesize
\caption{Class-wise F1 (\%) of the Linear SVM on the published split (S1) and on the source-held-out split (S3), with the S3 test support.}
\label{tab:src_classwise}
\begin{tabular}{lrrr}
\toprule
Class & S1 & S3 & S3 support \\
\midrule
""" + rows + r"""\bottomrule
\end{tabular}
\end{table}
""")


# ---------------------------------------------------------------- leakage effect and threshold sensitivity
p = f"{R}/leak_effect.csv"
if os.path.exists(p):
    le = pd.read_csv(p)
    rows = ""
    for t in (0.6, 0.8, 0.9):
        nd_t = json.load(open(f"{R}/near_dup_summary_t{int(t*100)}.json"))
        sub = le[le.threshold == t]
        cells = []
        for m in ["MNB_counts", "LinearSVM_tfidf", "fastText", "BiLSTM_GloVe", "BERTurk"]:
            x = sub[sub.model == m]
            cells.append(f"{100*x.macro_f1_clean.iloc[0]:.1f}" if len(x) else PEND)
        rows += f"{t:.1f} & {nd_t['n_pairs']:,} & {pct(nd_t['share_articles_in_clusters'],2)} & {pct(nd_t['redundant_share'],2)} & {nd_t['leakage']['test']['with_train_near_dup']:,} ({pct(nd_t['leakage']['test']['share'],2)}) & {pct(nd_t['pair_label_agreement'])} & " + " & ".join(cells) + r" \\" + "\n"
    full = [f"{100*le[(le.threshold==0.8)&(le.model==m)].macro_f1_all.iloc[0]:.1f}" if len(le[(le.threshold==0.8)&(le.model==m)]) else PEND
            for m in ["MNB_counts", "LinearSVM_tfidf", "fastText", "BiLSTM_GloVe", "BERTurk"]]
    rows += r"\midrule" + "\n" + r"\multicolumn{6}{l}{Complete S1 test set (no articles removed)} & " + " & ".join(full) + r" \\" + "\n"
    write("tab_neardup", r"""\begin{table*}[t]
\centering
\footnotesize
\setlength{\tabcolsep}{3.5pt}
\caption{Near-duplicate statistics at three Jaccard thresholds and S1 test macro-F1 (\%) after removing the test articles that have a near-duplicate in the S1 training set. Clustered: share of articles that belong to a near-duplicate cluster; Redundant: share of articles that would be removed by keeping one article per cluster; Leaked test: test articles with a near-duplicate in the training set; Label agr.: share of near-duplicate pairs with the same label.}
\label{tab:neardup}
\resizebox{\textwidth}{!}{%
\begin{tabular}{rrrrrrccccc}
\toprule
 & & & & & & \multicolumn{5}{c}{Macro-F1 on the reduced S1 test set} \\
\cmidrule(lr){7-11}
$J$ & Pairs & Clustered (\%) & Redundant (\%) & Leaked test (\%) & Label agr. (\%) & MNB & SVM & fastText & BiLSTM & BERTurk \\
\midrule
""" + rows + r"""\bottomrule
\end{tabular}}
\end{table*}
""")
    x = le[(le.threshold == 0.8) & (le.model == "LinearSVM_tfidf")].iloc[0]
    mac("LeakAccSVM", pct(x.acc_leaked)); mac("NonLeakAccSVM", pct(x.acc_nonleaked))
    mx = le[le.threshold == 0.6]
    mac("MaxLeakDrop", f"{100*(mx.macro_f1_all - mx.macro_f1_clean).max():.1f}")
    for t, nm in ((0.6, "Sixty"), (0.9, "Ninety")):
        nd_t = json.load(open(f"{R}/near_dup_summary_t{int(t*100)}.json"))
        mac(f"NDleakTestShare{nm}", pct(nd_t["leakage"]["test"]["share"], 2)); mac(f"NDshare{nm}", pct(nd_t["share_articles_in_clusters"], 2))

# ---------------------------------------------------------------- additional source-held-out folds
fs = sorted(glob.glob(f"{R}/source_folds_svm_*.csv"))
if fs:
    sf = pd.concat([pd.read_csv(f) for f in fs])
    r3 = load("split_source_heldout", "LinearSVM_tfidf")
    allf = list(sf.macro_f1) + [r3["test"]["macro_f1"]]
    alla = list(sf.accuracy) + [r3["test"]["accuracy"]]
    mac("SrcFoldsN", str(len(allf))); mac("SrcFoldsMF", f"{100*np.mean(allf):.1f}"); mac("SrcFoldsMFsd", f"{100*np.std(allf, ddof=1):.1f}")
    mac("SrcFoldsMFmin", f"{100*min(allf):.1f}"); mac("SrcFoldsMFmax", f"{100*max(allf):.1f}")
    mac("SrcFoldsAcc", f"{100*np.mean(alla):.1f}")
    cls_cols = [f"f1_{c}" for c in CLASSES]
    s1 = load("split_orig", "LinearSVM_tfidf")
    rows = ""
    for c in CLASSES:
        v = list(sf[f"f1_{c}"]) + [r3["test"]["per_class"][c]["f1"]]
        rows += f"{EN[c]} & {pct(s1['test']['per_class'][c]['f1'])} & {100*np.mean(v):.1f} $\\pm$ {100*np.std(v, ddof=1):.1f} & {100*min(v):.1f}--{100*max(v):.1f}" + r" \\" + "\n"
        mac(f"SrcF{''.join(ch for ch in EN[c] if ch.isalpha())}", f"{100*np.mean(v):.1f}")
    rows += r"\midrule" + "\n" + f"Macro-F1 & {pct(s1['test']['macro_f1'])} & {100*np.mean(allf):.1f} $\\pm$ {100*np.std(allf, ddof=1):.1f} & {100*min(allf):.1f}--{100*max(allf):.1f}" + r" \\" + "\n"
    write("tab_src_classwise", r"""\begin{table}[t]
\centering
\footnotesize
\caption{Linear SVM on the published split (S1) and on """ + str(len(allf)) + r""" source-held-out folds (fold 0 is the released S3 split): class-wise and macro-F1 (\%), mean $\pm$ SD and range over the folds.}
\label{tab:src_classwise}
\begin{tabular}{lrcc}
\toprule
Class & S1 & Source-held-out & Range \\
\midrule
""" + rows + r"""\bottomrule
\end{tabular}
\end{table}
""")

# ---------------------------------------------------------------- near-duplicates
nd = json.load(open(f"{R}/near_dup_summary_t80.json"))
sps = json.load(open(f"{R}/splits_summary.json"))
mac("NDpairs", f"{nd['n_pairs']:,}"); mac("NDclusters", f"{nd['n_clusters_gt1']:,}"); mac("NDarticles", f"{nd['n_articles_in_clusters']:,}")
mac("NDshare", pct(nd["share_articles_in_clusters"], 2)); mac("NDredundant", f"{nd['redundant_articles']:,}")
mac("NDredshare", pct(nd["redundant_share"], 2)); mac("NDlargest", str(nd["largest_cluster"]))
mac("NDlabagree", pct(nd["pair_label_agreement"], 1)); mac("NDsamesource", pct(nd["pair_same_source"], 1))
mac("NDleakTest", f"{nd['leakage']['test']['with_train_near_dup']:,}"); mac("NDleakTestShare", pct(nd["leakage"]["test"]["share"], 2))
mac("NDleakVal", f"{nd['leakage']['validation']['with_train_near_dup']:,}")
mac("NDclustersSpanSources", f"{nd['clusters_spanning_sources']:,}"); mac("NDclustersLabDis", f"{nd['clusters_with_label_disagreement']:,}")
mac("CleanTestSize", f"{sps['s1_clean_test_size']:,}")
mac("SrcTestSources", str(sps["split_source_heldout"]["n_test_sources"]))
mac("SrcTestSize", f"{sps['split_source_heldout']['sizes']['test']:,}"); mac("SrcTrainSize", f"{sps['split_source_heldout']['sizes']['train']:,}")
mac("SrcValSize", f"{sps['split_source_heldout']['sizes']['validation']:,}")
mac("SrcLeak", f"{sps['split_source_heldout']['test_with_train_near_dup']:,}")
mac("SrcMinShare", pct(sps["split_source_heldout"]["min_class_share_in_test"], 1)); mac("SrcMaxShare", pct(sps["split_source_heldout"]["max_class_share_in_test"], 1))
for t in (60, 70, 90):
    p = f"{R}/near_dup_summary_t{t}.json"
    if os.path.exists(p):
        x = json.load(open(p))
        mac(f"NDleakTestShareT{['','','','','','','sixty','seventy','','ninety'][t//10]}", pct(x["leakage"]["test"]["share"], 2))
        mac(f"NDshareT{['','','','','','','sixty','seventy','','ninety'][t//10]}", pct(x["share_articles_in_clusters"], 2))

# ---------------------------------------------------------------- cross-dataset
p = f"{R}/cross_dataset_summary.csv"
if os.path.exists(p):
    cs = pd.read_csv(p)
    conds = ["TTC-4900 (7 classes)", "TTC-4900 (6 shared classes)", "TRNEWS-2025 balanced (6 shared classes)", "TRNEWS-2025 balanced (9 classes)"]
    rows = ""
    for c in conds:
        cells = []
        for m in ["MNB", "LinearSVM", "fastText"]:
            x = cs[(cs.condition == c) & (cs.model == m)].iloc[0]
            cells.append(f"{100*x.macro_f1_mean:.1f} $\\pm$ {100*x.macro_f1_sd:.1f}")
            mac(f"CD{c.split()[0]}{''.join(ch for ch in c.split('(')[1] if ch.isalnum())}{m}", f"{100*x.macro_f1_mean:.1f}")
        n = {"TTC-4900 (7 classes)": "4,900", "TTC-4900 (6 shared classes)": "4,200",
             "TRNEWS-2025 balanced (6 shared classes)": "4,200", "TRNEWS-2025 balanced (9 classes)": "6,300"}[c]
        rows += f"{c.replace('TRNEWS-2025 balanced', 'TRNEWS-2025, balanced sample')} & {n} & " + " & ".join(cells) + r" \\" + "\n"
    write("tab_crossdataset", r"""\begin{table*}[t]
\centering
\footnotesize
\caption{Controlled cross-dataset comparison: identical preprocessing, models and protocol (stratified 5-fold cross-validation, 700 articles per class). Macro-F1 (\%), mean $\pm$ SD over folds (TTC-4900) and over folds and five random draws (TRNEWS-2025). Shared classes: Politics, Economy/Finance, Culture/Arts, Health, Sports, Technology/Science.}
\label{tab:crossdataset}
\begin{tabular}{lrccc}
\toprule
Condition & Articles & MNB & Linear SVM & fastText \\
\midrule
""" + rows + r"""\bottomrule
\end{tabular}
\end{table*}
""")

# ---------------------------------------------------------------- label provenance
p = f"{R}/label_audit_summary.json"
if os.path.exists(p):
    la = json.load(open(p))
    mac("URLmapped", f"{la['n_with_mapped_section']:,}"); mac("URLmappedShare", pct(la["share_with_mapped_section"], 1))
    mac("URLagree", pct(la["agreement_overall"], 1))
    mac("NDclusterLabConsistent", pct(la["near_dup_clusters_label_consistent"], 1))
    pc = pd.read_csv(f"{R}/url_section_agreement_by_urlclass.csv", index_col=0)
    pl = pd.read_csv(f"{R}/url_section_agreement_by_label.csv", index_col=0)
    rows = ""
    for c in CLASSES:
        rows += f"{EN[c]} & {int(pc.loc[c,'n_mapped']):,} & {pct(pc.loc[c,'agreement'])} & {int(pl.loc[c,'n_mapped']):,} & {pct(pl.loc[c,'share_of_label_matching_url'])}" + r" \\" + "\n"
    write("tab_urlsections", r"""\begin{table}[t]
\centering
\footnotesize
\caption{Agreement between the class label and the publisher's URL section (for articles whose URL contains an unambiguous section token, see the supplementary mapping table). Left: share of articles in a section mapped to class $c$ that carry label $c$; right: share of articles labelled $c$ (with a mapped section) whose URL section maps to $c$.}
\label{tab:urlsections}
\setlength{\tabcolsep}{4pt}
\begin{tabular}{lrrrr}
\toprule
 & \multicolumn{2}{c}{URL section $\rightarrow$ label} & \multicolumn{2}{c}{label $\rightarrow$ URL section} \\
\cmidrule(lr){2-3}\cmidrule(lr){4-5}
Class & $n$ & Agree (\%) & $n$ & Agree (\%) \\
\midrule
""" + rows + r"""\bottomrule
\end{tabular}
\end{table}
""")

# label audit (filled in by 07_audit_agreement.py once the annotation sheets are returned)
p = f"{R}/label_audit_summary.json"
if os.path.exists(p):
    mac("AuditSources", str(json.load(open(p))["audit_sample"]["n_sources"]))
p = f"{R}/label_audit_agreement.json"
if os.path.exists(p):
    au = json.load(open(p))
    mac("AuditKappa", f"{au['kappa_annotators']:.2f}"); mac("AuditAcc", pct(au["agreement_with_dataset"]))
    mac("AuditMacro", pct(au["macro_agreement_with_dataset"]))
gp = [load(sp_, m_) for sp_, _ in SPLITS for m_ in ("BiLSTM_GloVe", "BERTurk")]
gp = [g for g in gp if g]
if gp:
    mac("GPUname", gp[0]["hardware"]["gpu"].replace("NVIDIA ", "NVIDIA~"))
for k in ["AuditKappa", "AuditAcc", "AuditMacro", "AuditSources", "GPUname", "SrcFoldsN", "SrcFoldsMF", "SrcFoldsMFsd", "SrcFoldsMFmin", "SrcFoldsMFmax", "SrcFoldsAcc", "SrcFFinanceEconomy", "SrcFScienceTechnology", "SrcFEnvironment", "SrcFArtsCulture", "SrcFTourism", "MFBiLSTMGloVe", "AccBiLSTMGloVe", "MFBERTurk", "AccBERTurk", "EnvFOneBERTurk", "EnvFOneBiLSTMGloVe", "MFsrcBERTurk", "MFsrcBiLSTMGloVe", "DsrcBERTurk", "DsrcBiLSTMGloVe"]:
    MAC.setdefault(k, PEND)

with open(f"{OUT}/macros.tex", "w") as f:
    f.write("\\providecommand{\\pending}{\\textcolor{red}{[pending]}}\n")
    for k, v in MAC.items():
        f.write(f"\\newcommand{{\\{k}}}{{{v}}}\n")
print(len(MAC), "macros;", sorted(os.listdir(OUT)))
