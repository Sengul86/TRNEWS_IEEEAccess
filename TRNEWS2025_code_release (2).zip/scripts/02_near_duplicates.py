"""Near-duplicate detection with MinHash-LSH over word 5-gram shingles.

Outputs
  data/near_dup_clusters.parquet  : id, cluster (connected component of pairs with estimated Jaccard >= THRESH)
  results/near_dup_summary.json   : overall statistics, cross-split leakage, label consistency
  results/near_dup_pairs_sample.csv : random sample of detected pairs for manual inspection
"""
import json, re, sys, zlib, time
from multiprocessing import Pool
import numpy as np, pandas as pd, pyarrow.parquet as pq

THRESH = float(sys.argv[1]) if len(sys.argv) > 1 else 0.8
K, NPERM, BANDS = 5, 128, 32            # 5-word shingles, 128 permutations, 32 bands x 4 rows (S-curve ~0.42)
ROWS = NPERM // BANDS
P = (1 << 61) - 1
rng = np.random.RandomState(12345)
A = rng.randint(1, 1 << 31, size=NPERM, dtype=np.int64).astype(np.uint64)
B = rng.randint(0, 1 << 31, size=NPERM, dtype=np.int64).astype(np.uint64)
MAXU32 = np.uint64(0xFFFFFFFF)
WORD = re.compile(r"\w+", re.UNICODE)

def norm_tokens(text):
    return WORD.findall((text or "").lower().replace("i̇", "i"))

def signature(text):
    toks = norm_tokens(text)
    if len(toks) < K:
        sh = {" ".join(toks)} if toks else {""}
    else:
        sh = {" ".join(toks[i:i + K]) for i in range(len(toks) - K + 1)}
    h = np.fromiter((zlib.crc32(s.encode("utf-8")) for s in sh), dtype=np.uint64, count=len(sh))
    # universal hashing (a*h+b) mod 2^32 per permutation; min over shingles
    v = (np.outer(h, A) + B) & MAXU32
    return v.min(axis=0).astype(np.uint32)

def work(chunk):
    return np.stack([signature(t) for t in chunk])

if __name__ == "__main__":
    t0 = time.time()
    df = pq.read_table("data/trnews.parquet", columns=["id", "text", "label", "split_orig", "source"]).to_pandas()
    texts = df.text.tolist()
    chunks = [texts[i:i + 2000] for i in range(0, len(texts), 2000)]
    with Pool(4) as pool:
        sig = np.vstack(pool.map(work, chunks, chunksize=4))
    del texts, chunks
    np.save(f"data/minhash_sig_t{int(THRESH*100)}.npy" if THRESH != 0.8 else "data/minhash_sig.npy", sig)
    print(f"signatures {sig.shape} in {time.time()-t0:.0f}s", flush=True)

    # LSH banding -> candidate pairs
    n = len(df)
    cand = set()
    for b in range(BANDS):
        band = np.ascontiguousarray(sig[:, b * ROWS:(b + 1) * ROWS]).view(np.dtype((np.void, ROWS * 4))).ravel()
        order = np.argsort(band, kind="stable"); sb = band[order]
        starts = np.flatnonzero(np.r_[True, sb[1:] != sb[:-1]]); ends = np.r_[starts[1:], n]
        for s, e in zip(starts, ends):
            if e - s < 2:
                continue
            members = order[s:e]
            if e - s > 2000:          # very large buckets are boilerplate; keep a star around the first element
                members = members[:2000]
            m0 = members.min()
            for j in members:
                if j != m0:
                    cand.add((m0, j) if m0 < j else (j, m0))
            if e - s <= 50:
                for i1 in range(len(members)):
                    for i2 in range(i1 + 1, len(members)):
                        a, c = members[i1], members[i2]
                        cand.add((a, c) if a < c else (c, a))
        print(f"band {b}: {len(cand)} candidates", flush=True)
    cand = np.array(sorted(cand), dtype=np.int64)
    est = np.empty(len(cand), np.float32)
    for i in range(0, len(cand), 1_000_000):
        c = cand[i:i + 1_000_000]
        est[i:i + 1_000_000] = (sig[c[:, 0]] == sig[c[:, 1]]).mean(1)
    keep = est >= THRESH
    pairs, pest = cand[keep], est[keep]
    print(f"{len(pairs)} pairs with est. Jaccard >= {THRESH}", flush=True)

    # connected components (union-find)
    parent = np.arange(n)
    def find(x):
        r = x
        while parent[r] != r:
            r = parent[r]
        while parent[x] != r:
            parent[x], x = r, parent[x]
        return r
    for a, c in pairs:
        ra, rc = find(a), find(c)
        if ra != rc:
            parent[max(ra, rc)] = min(ra, rc)
    comp = np.array([find(i) for i in range(n)])
    df["cluster"] = comp
    size = df.groupby("cluster").id.transform("size")
    df["cluster_size"] = size
    df[["id", "cluster", "cluster_size"]].to_parquet("data/near_dup_clusters.parquet" if THRESH == 0.8 else f"data/near_dup_clusters_t{int(THRESH*100)}.parquet", index=False)

    in_cl = df[df.cluster_size > 1]
    g = in_cl.groupby("cluster")
    n_lab = g.label.nunique(); n_split = g.split_orig.nunique(); n_src = g.source.nunique()
    # cross-split leakage: test/validation articles having a near-duplicate in train
    has_train = g.split_orig.apply(lambda s: (s == "train").any())
    df["cl_has_train"] = df.cluster.map(has_train).fillna(False)
    leak = {}
    for s in ["validation", "test"]:
        sub = df[df.split_orig == s]
        leak[s] = dict(n=int(len(sub)), with_train_near_dup=int(((sub.cluster_size > 1) & sub.cl_has_train).sum()),
                       share=float(((sub.cluster_size > 1) & sub.cl_has_train).mean()))
    a_lab = df.label.values
    pair_lab_agree = float((a_lab[pairs[:, 0]] == a_lab[pairs[:, 1]]).mean()) if len(pairs) else float("nan")
    src = df.source.values
    pair_same_src = float((src[pairs[:, 0]] == src[pairs[:, 1]]).mean()) if len(pairs) else float("nan")
    summ = dict(threshold=THRESH, shingle_k=K, num_perm=NPERM, bands=BANDS, n_articles=int(n), n_pairs=int(len(pairs)),
                n_clusters_gt1=int((g.size() > 1).sum()), n_articles_in_clusters=int(len(in_cl)),
                share_articles_in_clusters=float(len(in_cl) / n),
                redundant_articles=int(len(in_cl) - g.ngroups), redundant_share=float((len(in_cl) - g.ngroups) / n),
                largest_cluster=int(g.size().max()) if len(in_cl) else 0,
                clusters_with_label_disagreement=int((n_lab > 1).sum()),
                articles_in_label_disagreeing_clusters=int(in_cl.cluster.isin(n_lab[n_lab > 1].index).sum()),
                pair_label_agreement=pair_lab_agree, pair_same_source=pair_same_src,
                clusters_spanning_splits=int((n_split > 1).sum()), clusters_spanning_sources=int((n_src > 1).sum()),
                leakage=leak, runtime_s=round(time.time() - t0))
    json.dump(summ, open(f"results/near_dup_summary_t{int(THRESH*100)}.json", "w"), indent=2)
    print(json.dumps(summ, indent=2))
    smp = np.random.RandomState(0).choice(len(pairs), size=min(200, len(pairs)), replace=False)
    rows = []
    for i in smp:
        a, c = pairs[i]
        rows.append(dict(est_jaccard=float(pest[i]), id_a=df.id[a], id_b=df.id[c], label_a=df.label[a], label_b=df.label[c],
                         split_a=df.split_orig[a], split_b=df.split_orig[c], source_a=df.source[a], source_b=df.source[c]))
    pd.DataFrame(rows).to_csv(f"results/near_dup_pairs_sample_t{int(THRESH*100)}.csv", index=False)
    np.save(f"data/near_dup_pairs_t{int(THRESH*100)}.npy", np.c_[pairs, (pest * 1000).astype(np.int64)])
