# %% [markdown]
# # TRNEWS-2025 – BiLSTM–GloVe and BERTurk on the three evaluation splits (GPU)
#
# This notebook re-runs the two neural baselines of the paper with a **clean protocol**:
# * the partition is read from `trnews2025_split_assignments.csv.gz` (column `split_orig`, `split_dedup_grouped` or
#   `split_source_heldout`);
# * the **validation** partition is used for early stopping / checkpoint selection, the **test** partition only once
#   at the end;
# * results are written as JSON files with the same schema as the CPU baselines (`results/runs/<split>__<model>.json`).
#
# Runtime → Change runtime type → **GPU** (A100/L4 recommended; T4 works with the default sequence lengths).
#
# Required files in `DATA_DIR` (Google Drive):
# `trnews_train.csv`, `trnews_validation.csv`, `trnews_test.csv`, `trnews2025_split_assignments.csv.gz`,
# and for BiLSTM–GloVe the Turkish GloVe vectors (`vectors.txt`, 300-d; inzva Turkish GloVe).

# %%
# !pip -q install transformers accelerate

# %%
import os, json, time, re, gc, platform
import numpy as np, pandas as pd
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix

IN_COLAB = "google.colab" in str(get_ipython()) if "get_ipython" in globals() else False
if IN_COLAB:
    from google.colab import drive
    drive.mount("/content/drive")
DATA_DIR = os.environ.get("TRN_DATA", "/content/drive/MyDrive/TRNEWS2025")
OUT_DIR = os.path.join(DATA_DIR, "results/runs"); os.makedirs(OUT_DIR, exist_ok=True)
GLOVE_PATH = os.path.join(DATA_DIR, "vectors.txt")

SPLITS = ["split_orig", "split_dedup_grouped", "split_source_heldout"]   # run a subset if time is limited
RUN_BILSTM, RUN_BERT = True, True
SEED = 42
CLASSES = ["Magazin", "Siyaset", "Spor", "Kültür-Sanat", "Sağlık", "Finans-Ekonomi", "Bilim-Teknoloji", "Turizm", "Çevre"]

# BiLSTM–GloVe settings (as described in the paper)
BILSTM = dict(max_len=512, vocab=100_000, emb_dim=300, units=100, lr=1e-3, batch=128, epochs=8, class_weight=True)
# BERTurk settings. max_len 256 keeps one epoch at ~1.5–3 h on an A100/L4; set 512 if the budget allows.
BERT = dict(model="dbmdz/bert-base-turkish-uncased", max_len=256, lr=2e-5, batch=32, epochs=2, warmup=0.06, weight_decay=0.01,
            eval_every_frac=0.25)

# %%
frames = [pd.read_csv(os.path.join(DATA_DIR, f"trnews_{s}.csv")) for s in ["train", "validation", "test"]]
df = pd.concat(frames, ignore_index=True).rename(columns={"ID": "id", "Haber Gövdesi": "text", "Sınıf": "label"})
sp = pd.read_csv(os.path.join(DATA_DIR, "trnews2025_split_assignments.csv.gz"))
df = df.merge(sp, on=["id", "label"], how="inner")
assert len(df) == 801589, len(df)
df["y"] = df.label.map({c: i for i, c in enumerate(CLASSES)})
def tr_lower(s): return s.replace("I", "ı").replace("İ", "i").lower()
df["text"] = df.text.astype(str).map(tr_lower)
print(df.groupby("split_orig").size())

def metrics(yt, yp):
    p, r, f, _ = precision_recall_fscore_support(yt, yp, labels=range(9), zero_division=0)
    P, R, F, _ = precision_recall_fscore_support(yt, yp, labels=range(9), average="macro", zero_division=0)
    return dict(accuracy=accuracy_score(yt, yp), macro_p=P, macro_r=R, macro_f1=F,
                per_class={c: dict(p=float(p[i]), r=float(r[i]), f1=float(f[i]), support=int((yt == i).sum())) for i, c in enumerate(CLASSES)},
                confusion=confusion_matrix(yt, yp, labels=range(9)).tolist())

def gpu_name():
    try:
        import torch; return torch.cuda.get_device_name(0)
    except Exception:
        return "unknown"

def save(col, name, yp, te_mask, t_train, t_test, cfg, history):
    yt = df.y.values[te_mask]
    res = dict(model=name, split=col, config=cfg, history=history, hardware=dict(gpu=gpu_name(), cpu=platform.processor()),
               train_time_s=round(t_train, 1), test_time_s=round(t_test, 2), n_train=int((df[col] == "train").sum()),
               n_test=int(te_mask.sum()), test=metrics(yt, yp))
    if col == "split_orig":
        clean = ~df.s1_test_has_train_near_dup.values[te_mask]
        res["test_clean"] = metrics(yt[clean], yp[clean]); res["n_test_clean"] = int(clean.sum())
    json.dump(res, open(os.path.join(OUT_DIR, f"{col}__{name}.json"), "w"), indent=1)
    print(f"{col} {name}: acc {res['test']['accuracy']:.4f} macro-F1 {res['test']['macro_f1']:.4f}")

# %% [markdown]
# ## BiLSTM–GloVe (TensorFlow/Keras)

# %%
if RUN_BILSTM:
    import tensorflow as tf
    from tensorflow import keras
    from tensorflow.keras import layers
    tf.keras.utils.set_random_seed(SEED)
    glove = {}
    with open(GLOVE_PATH, encoding="utf-8", errors="ignore") as f:
        for line in f:
            parts = line.rstrip().split(" ")
            if len(parts) == BILSTM["emb_dim"] + 1:
                glove[parts[0]] = np.asarray(parts[1:], dtype="float32")
    print(len(glove), "GloVe vectors")

    for col in SPLITS:
        tr, va, te = [(df[col] == s).values for s in ("train", "validation", "test")]
        vec = layers.TextVectorization(max_tokens=BILSTM["vocab"], output_sequence_length=BILSTM["max_len"],
                                       standardize="strip_punctuation", split="whitespace")
        vec.adapt(tf.data.Dataset.from_tensor_slices(df.text.values[tr]).batch(4096))    # vocabulary from training texts only
        vocab = vec.get_vocabulary()
        E = np.zeros((len(vocab), BILSTM["emb_dim"]), "float32"); hit = 0
        for i, w in enumerate(vocab):
            if w in glove:
                E[i] = glove[w]; hit += 1
        print(f"{col}: vocabulary {len(vocab)}, GloVe coverage {hit/len(vocab):.3f}")
        def ds(mask, shuffle):
            d = tf.data.Dataset.from_tensor_slices((df.text.values[mask], df.y.values[mask]))
            if shuffle:
                d = d.shuffle(200_000, seed=SEED)
            return d.batch(BILSTM["batch"]).map(lambda x, y: (vec(x), y), num_parallel_calls=tf.data.AUTOTUNE).prefetch(tf.data.AUTOTUNE)
        inp = keras.Input((BILSTM["max_len"],), dtype="int64")
        x = layers.Embedding(len(vocab), BILSTM["emb_dim"], embeddings_initializer=keras.initializers.Constant(E), trainable=False, mask_zero=False)(inp)
        x = layers.Bidirectional(layers.LSTM(BILSTM["units"], return_sequences=True))(x)
        x = layers.GlobalMaxPooling1D()(x)
        out = layers.Dense(9, activation="softmax")(x)
        model = keras.Model(inp, out)
        model.compile(keras.optimizers.RMSprop(BILSTM["lr"]), "sparse_categorical_crossentropy", metrics=["accuracy"])
        cw = None
        if BILSTM["class_weight"]:
            cnt = np.bincount(df.y.values[tr], minlength=9); cw = {i: float(cnt.sum() / (9 * cnt[i])) for i in range(9)}
        best, best_f1, hist = None, -1, []
        t0 = time.time()
        for ep in range(BILSTM["epochs"]):
            h = model.fit(ds(tr, True), epochs=1, class_weight=cw, verbose=1)
            pv = model.predict(ds(va, False), verbose=0).argmax(1)
            f1v = precision_recall_fscore_support(df.y.values[va], pv, average="macro", zero_division=0)[2]
            hist.append(dict(epoch=ep + 1, train_loss=float(h.history["loss"][0]), val_macro_f1=float(f1v)))
            print(hist[-1])
            if f1v > best_f1:
                best_f1, best = f1v, model.get_weights()
        t_train = time.time() - t0
        model.set_weights(best)
        t0 = time.time(); yp = model.predict(ds(te, False), verbose=0).argmax(1); t_test = time.time() - t0
        save(col, "BiLSTM_GloVe", yp, te, t_train, t_test, dict(BILSTM, glove_coverage=hit / len(vocab)), hist)
        del model; keras.backend.clear_session(); gc.collect()

# %% [markdown]
# ## BERTurk (PyTorch / Hugging Face)

# %%
if RUN_BERT:
    import torch
    from torch.utils.data import Dataset, DataLoader
    from transformers import AutoTokenizer, AutoModelForSequenceClassification, get_linear_schedule_with_warmup
    torch.manual_seed(SEED)
    dev = "cuda"
    # the uncased BERTurk tokenizer strips Turkish diacritics by default (ü->u, ş->s); keep them and rely on our Turkish lowercasing
    tok = AutoTokenizer.from_pretrained(BERT["model"], strip_accents=False, do_lower_case=False)
    class DS(Dataset):
        def __init__(self, texts, y): self.t, self.y = texts, y
        def __len__(self): return len(self.t)
        def __getitem__(self, i): return self.t[i], self.y[i]
    def collate(b):
        enc = tok([x for x, _ in b], truncation=True, max_length=BERT["max_len"], padding=True, return_tensors="pt")
        enc["labels"] = torch.tensor([y for _, y in b]); return enc
    def predict(model, texts):
        dl = DataLoader(DS(texts, np.zeros(len(texts), int)), batch_size=128, collate_fn=collate, num_workers=2)
        out = []
        model.eval()
        with torch.no_grad(), torch.autocast("cuda", dtype=torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16):
            for b in dl:
                b = {k: v.to(dev) for k, v in b.items() if k != "labels"}
                out.append(model(**b).logits.argmax(-1).cpu().numpy())
        model.train(); return np.concatenate(out)

    for col in SPLITS:
        tr, va, te = [(df[col] == s).values for s in ("train", "validation", "test")]
        model = AutoModelForSequenceClassification.from_pretrained(BERT["model"], num_labels=9).to(dev)
        dl = DataLoader(DS(df.text.values[tr].tolist(), df.y.values[tr]), batch_size=BERT["batch"], shuffle=True,
                        collate_fn=collate, num_workers=2, generator=torch.Generator().manual_seed(SEED))
        opt = torch.optim.AdamW(model.parameters(), lr=BERT["lr"], weight_decay=BERT["weight_decay"])
        steps = len(dl) * BERT["epochs"]
        sch = get_linear_schedule_with_warmup(opt, int(BERT["warmup"] * steps), steps)
        scaler = torch.amp.GradScaler("cuda", enabled=not torch.cuda.is_bf16_supported())
        eval_every = int(len(dl) * BERT["eval_every_frac"])
        # validation subset for frequent checkpoint selection (full validation set at the end of every epoch)
        va_idx = np.flatnonzero(va); rng = np.random.RandomState(SEED)
        va_sub = rng.choice(va_idx, size=min(20_000, len(va_idx)), replace=False)
        best_f1, best_state, hist, step = -1, None, [], 0
        t0 = time.time()
        for ep in range(BERT["epochs"]):
            for b in dl:
                b = {k: v.to(dev) for k, v in b.items()}
                with torch.autocast("cuda", dtype=torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16):
                    loss = model(**b).loss
                scaler.scale(loss).backward(); scaler.unscale_(opt)
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                scaler.step(opt); scaler.update(); opt.zero_grad(); sch.step(); step += 1
                if step % eval_every == 0 or step == steps:
                    pv = predict(model, df.text.values[va_sub].tolist())
                    f1v = precision_recall_fscore_support(df.y.values[va_sub], pv, average="macro", zero_division=0)[2]
                    hist.append(dict(step=step, epoch=step / len(dl), train_loss=float(loss), val_macro_f1=float(f1v)))
                    print(hist[-1], flush=True)
                    if f1v > best_f1:
                        best_f1 = f1v; best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        t_train = time.time() - t0
        model.load_state_dict(best_state)
        t0 = time.time(); yp = predict(model, df.text.values[te].tolist()); t_test = time.time() - t0
        save(col, "BERTurk", yp, te, t_train, t_test, BERT, hist)
        del model, opt; gc.collect(); torch.cuda.empty_cache()

# %%
print("Done. Copy the JSON files in", OUT_DIR, "back to the revision folder (results/runs/) to update the tables.")
