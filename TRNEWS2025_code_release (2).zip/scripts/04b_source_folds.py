"""Linear SVM on additional source-held-out folds (StratifiedGroupKFold over source domains, 10 folds).
Fold k is used as test and fold (k+1) mod 10 as validation (validation not used: fixed hyperparameters).
Writes results/source_folds_svm.csv with accuracy and macro-F1 per test fold."""
import sys, time, json
import numpy as np, pandas as pd, pyarrow.parquet as pq
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.feature_extraction.text import HashingVectorizer, TfidfTransformer
from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score, f1_score

CLASSES = ["Magazin", "Siyaset", "Spor", "Kültür-Sanat", "Sağlık", "Finans-Ekonomi", "Bilim-Teknoloji", "Turizm", "Çevre"]
folds_to_run = [int(x) for x in sys.argv[1].split(",")]
sp = pd.read_parquet("data/splits.parquet")
y = sp.label.map({c: i for i, c in enumerate(CLASSES)}).values
sgkf = StratifiedGroupKFold(n_splits=10, shuffle=True, random_state=42)
fold = np.empty(len(sp), int)
for k, (_, te) in enumerate(sgkf.split(np.zeros(len(sp)), sp.label.values, sp.source.values)):
    fold[te] = k
assert ((fold == 0) == (sp.split_source_heldout.values == "test")).all()   # fold 0 is the released S3 test set
text = pq.read_table("data/trnews.parquet", columns=["text"]).column("text").to_pylist()
hv = HashingVectorizer(ngram_range=(1, 2), n_features=2 ** 21, alternate_sign=False, norm=None, token_pattern=r"(?u)\b\w+\b", dtype=np.float32)
assert len(folds_to_run) == 1, "run one fold per process to limit memory"
k = folds_to_run[0]
te_idx = np.flatnonzero(fold == k); tr_idx = np.flatnonzero((fold != k) & (fold != (k + 1) % 10))
low = lambda t: t.replace("I", "ı").replace("İ", "i").lower()
Xtr = hv.transform(low(text[i]) for i in tr_idx); Xte = hv.transform(low(text[i]) for i in te_idx); del text
rows = []
for k in folds_to_run:
    te = fold == k
    t0 = time.time()
    tf = TfidfTransformer(sublinear_tf=True).fit(Xtr)
    Ttr = tf.transform(Xtr, copy=False); del Xtr
    clf = LinearSVC(C=0.5, class_weight="balanced", dual=True, max_iter=2000, random_state=42).fit(Ttr, y[tr_idx]); del Ttr
    p = clf.predict(tf.transform(Xte))
    pc = f1_score(y[te], p, average=None, labels=range(9))
    rows.append(dict(fold=k, n_test=int(te.sum()), n_test_sources=int(sp.source[te].nunique()), accuracy=accuracy_score(y[te], p),
                     macro_f1=f1_score(y[te], p, average="macro"), **{f"f1_{c}": v for c, v in zip(CLASSES, pc)}, time_s=time.time() - t0))
    print(rows[-1], flush=True)
    pd.DataFrame(rows).to_csv(f"results/source_folds_svm_{sys.argv[1].replace(',', '-')}.csv", index=False)
