"""Label provenance and consistency analysis (Reviewer 2, comment 1).

1. URL-section analysis: for articles whose URL contains a publisher section token (e.g. /spor/, /ekonomi/),
   map frequent section tokens to the nine target classes with an explicit dictionary and measure how often the
   dataset label agrees with the class implied by the URL section, per class and per source.
2. Within-cluster label consistency of near-duplicates (from 02_near_duplicates.py).
3. A stratified audit sample (publisher x class) for independent manual re-annotation by two annotators, written to
   results/label_audit_sample.csv (annotators fill 'annotator1' and 'annotator2'); 07_audit_agreement.py computes
   agreement once the sheet is returned.
"""
import json, re
import numpy as np, pandas as pd, pyarrow.parquet as pq

CLASSES = ["Magazin", "Siyaset", "Spor", "Kültür-Sanat", "Sağlık", "Finans-Ekonomi", "Bilim-Teknoloji", "Turizm", "Çevre"]
# publisher section tokens -> target class (only unambiguous section names; generic sections such as /gundem/,
# /turkiye/, /dunya/, /yasam/ or /yerel-haberler/ are deliberately left unmapped)
SECTION_MAP = {
    "Magazin": ["magazin", "kelebek", "cadde", "televizyon", "tv", "unluler", "magazin-haberleri", "pembenar", "n-life", "trend"],
    "Siyaset": ["politika", "siyaset", "siyaset-haberleri", "politika-haberleri", "secim", "meclis"],
    "Spor": ["spor", "futbol", "basketbol", "voleybol", "sporarena", "skorer", "dunyadan-spor", "fenerbahce", "galatasaray",
             "besiktas", "trabzonspor", "sporskor", "zpor", "spor-haberleri", "takim", "transfer"],
    "Kültür-Sanat": ["kultur-sanat", "kultur", "sanat", "kitap", "sinema", "tiyatro", "muzik", "kultur-sanat-haberleri"],
    "Sağlık": ["saglik", "saglikli-yasam", "saglik-haberleri", "koronavirus", "beslenme", "hastalik"],
    "Finans-Ekonomi": ["ekonomi", "finans", "borsa", "piyasa", "piyasalar", "ekonomi-haberleri", "is-dunyasi", "isdunyasi", "para", "doviz", "altin"],
    "Bilim-Teknoloji": ["teknoloji", "bilim-teknoloji", "bilim", "bilim-ve-teknoloji", "teknoloji-haberleri", "tekno", "bilisim", "uzay", "oyun"],
    "Turizm": ["turizm", "seyahat", "gezi", "tatil", "turizm-haberleri"],
    "Çevre": ["cevre", "iklim", "doga", "cevre-haberleri", "iklim-krizi", "ekoloji"],
}
TOK2CLS = {t: c for c, ts in SECTION_MAP.items() for t in ts}

df = pq.read_table("data/trnews.parquet", columns=["id", "path", "label", "source", "n_words"]).to_pandas()
cl = pd.read_parquet("data/near_dup_clusters.parquet")
df["cluster"] = cl.cluster.values; df["cluster_size"] = cl.cluster_size.values

def section_class(path):
    segs = [re.sub(r"\.(html?|php|aspx?)$", "", s) for s in path.split("/") if s][:-1]   # exclude the article slug
    for s in segs[:3]:
        if s in TOK2CLS:
            return TOK2CLS[s], s
    return None, None

sc = [section_class(p) for p in df.path]
df["url_class"] = [a for a, _ in sc]; df["url_section"] = [b for _, b in sc]
m = df.url_class.notna()
agree = (df.label == df.url_class)[m]
rep = dict(n_articles=int(len(df)), n_with_mapped_section=int(m.sum()), share_with_mapped_section=float(m.mean()),
           agreement_overall=float(agree.mean()))
ct = pd.crosstab(df.url_class[m], df.label[m]).reindex(index=CLASSES, columns=CLASSES, fill_value=0)
ct.to_csv("results/url_section_vs_label_crosstab.csv")
per_cls = pd.DataFrame({"n_mapped": ct.sum(1), "agree": np.diag(ct.values)})
per_cls["agreement"] = per_cls.agree / per_cls.n_mapped
per_label = pd.DataFrame({"n_mapped": ct.sum(0), "agree": np.diag(ct.values)})
per_label["share_of_label_matching_url"] = per_label.agree / per_label.n_mapped
per_cls.to_csv("results/url_section_agreement_by_urlclass.csv"); per_label.to_csv("results/url_section_agreement_by_label.csv")
rep["agreement_by_url_class"] = per_cls.agreement.round(4).to_dict()
# mapping table with counts for documentation
rows = []
for c, toks in SECTION_MAP.items():
    for t in toks:
        sub = df[df.url_section == t]
        if len(sub):
            rows.append(dict(target_class=c, section_token=t, n_articles=len(sub), n_sources=sub.source.nunique(),
                             share_label_equal_target=float((sub.label == c).mean())))
pd.DataFrame(rows).sort_values(["target_class", "n_articles"], ascending=[True, False]).to_csv("results/section_mapping_table.csv", index=False)

# near-duplicate label consistency
inc = df[df.cluster_size > 1]
g = inc.groupby("cluster").label
rep["near_dup_clusters"] = int(g.ngroups)
rep["near_dup_clusters_label_consistent"] = float((g.nunique() == 1).mean())
# which label pairs disagree inside clusters
dis = inc[inc.cluster.isin(g.nunique()[g.nunique() > 1].index)]
pairs = {}
for _, s in dis.groupby("cluster").label:
    u = sorted(set(s))
    for i in range(len(u)):
        for j in range(i + 1, len(u)):
            pairs[f"{u[i]} / {u[j]}"] = pairs.get(f"{u[i]} / {u[j]}", 0) + 1
rep["near_dup_disagreeing_label_pairs_top"] = dict(sorted(pairs.items(), key=lambda x: -x[1])[:10])

# stratified audit sample: 100 articles per class, spread over sources (at most 3 per source and class)
rng = np.random.RandomState(2025)
sample = []
for c in CLASSES:
    sub = df[df.label == c].sample(frac=1, random_state=rng)
    sub = sub.groupby("source", group_keys=False).head(3)
    sample.append(sub.head(100))
samp = pd.concat(sample)
full = pq.read_table("data/trnews.parquet", columns=["id", "url", "text"]).to_pandas().set_index("id")
samp = samp.assign(url=full.loc[samp.id, "url"].values, text=full.loc[samp.id, "text"].str.slice(0, 1500).values)
samp = samp.sample(frac=1, random_state=1)[["id", "source", "url", "text", "label"]]
samp["annotator1"] = ""; samp["annotator2"] = ""
samp.rename(columns={"label": "dataset_label_hidden_from_annotators"}).to_csv("results/label_audit_sample_with_labels.csv", index=False)
samp.drop(columns=["label", "url"]).to_csv("results/label_audit_sheet_for_annotators.csv", index=False)
rep["audit_sample"] = dict(n=int(len(samp)), n_sources=int(samp.source.nunique()))
json.dump(rep, open("results/label_audit_summary.json", "w"), indent=2, ensure_ascii=False)
print(json.dumps(rep, indent=2, ensure_ascii=False))
print(per_cls); print(per_label)
