"""BiLSTM-GloVe on one split, CPU version of the GPU notebook (identical model and protocol).

Usage: python 11_bilstm_cpu.py <split_column> <glove vectors.txt>
Model: frozen 300-d Turkish GloVe (inzva, uncased) -> BiLSTM(100 per direction, all time steps) -> global max pooling
-> softmax(9). Vocabulary (100k) from training texts only; sequences padded/truncated to 512 tokens; RMSprop 1e-3,
batch 128, balanced class weights; at most 8 epochs, the epoch with the best validation macro-F1 is kept (early stop
after 2 epochs without improvement). The test partition is evaluated once.
"""
import json, os, sys, time, platform
import numpy as np, pandas as pd, pyarrow.parquet as pq
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix

col, glove_path = sys.argv[1], sys.argv[2]
CFG = dict(max_len=512, vocab=100_000, emb_dim=300, units=100, lr=1e-3, batch=128, max_epochs=8, patience=2, class_weight=True)
CLASSES = ["Magazin", "Siyaset", "Spor", "Kültür-Sanat", "Sağlık", "Finans-Ekonomi", "Bilim-Teknoloji", "Turizm", "Çevre"]
tf.keras.utils.set_random_seed(42)

text = pq.read_table("data/trnews.parquet", columns=["text"]).column("text").to_pylist()
text = np.array([t.replace("I", "ı").replace("İ", "i").lower() for t in text], dtype=object)
sp = pd.read_parquet("data/splits.parquet")
y = sp.label.map({c: i for i, c in enumerate(CLASSES)}).values.astype("int32")
tr, va, te = [(sp[col] == s).values for s in ("train", "validation", "test")]

vec = layers.TextVectorization(max_tokens=CFG["vocab"], output_sequence_length=CFG["max_len"],
                               standardize="strip_punctuation", split="whitespace")
vec.adapt(tf.data.Dataset.from_tensor_slices(text[tr]).batch(4096))
vocab = vec.get_vocabulary()
glove = {}
with open(glove_path, encoding="utf-8", errors="ignore") as f:
    for line in f:
        p = line.rstrip().split(" ")
        if len(p) == CFG["emb_dim"] + 1:
            glove[p[0]] = np.asarray(p[1:], dtype="float32")
E = np.zeros((len(vocab), CFG["emb_dim"]), "float32"); hit = 0
for i, w in enumerate(vocab):
    if w in glove:
        E[i] = glove[w]; hit += 1
del glove
print(f"{col}: vocabulary {len(vocab)}, GloVe coverage {hit/len(vocab):.3f}", flush=True)

def ds(mask, shuffle):
    d = tf.data.Dataset.from_tensor_slices((text[mask], y[mask]))
    if shuffle:
        d = d.shuffle(100_000, seed=42, reshuffle_each_iteration=True)
    return d.batch(CFG["batch"]).map(lambda a, b: (vec(a), b), num_parallel_calls=tf.data.AUTOTUNE).prefetch(4)

inp = keras.Input((CFG["max_len"],), dtype="int64")
x = layers.Embedding(len(vocab), CFG["emb_dim"], embeddings_initializer=keras.initializers.Constant(E), trainable=False)(inp)
x = layers.Bidirectional(layers.LSTM(CFG["units"], return_sequences=True))(x)
x = layers.GlobalMaxPooling1D()(x)
model = keras.Model(inp, layers.Dense(9, activation="softmax")(x))
model.compile(keras.optimizers.RMSprop(CFG["lr"]), "sparse_categorical_crossentropy")
cnt = np.bincount(y[tr], minlength=9); cw = {i: float(cnt.sum() / (9 * cnt[i])) for i in range(9)}

# Resumable: after every epoch the weights, the optimizer state, the best weights and the history are saved,
# because the cloud container may restart during the multi-hour CPU run.
CK = f"ckpt/bilstm_{col}"; os.makedirs(CK, exist_ok=True)
best_f1, hist, bad, elapsed0 = -1.0, [], 0, 0.0
if os.path.exists(f"{CK}/state.json"):
    st = json.load(open(f"{CK}/state.json")); best_f1, hist, bad, elapsed0 = st["best_f1"], st["hist"], st["bad"], st["elapsed"]
    model.load_weights(f"{CK}/last.weights.h5"); model.optimizer.build(model.trainable_variables)
    z = np.load(f"{CK}/opt.npz")
    for i, v in enumerate(model.optimizer.variables):
        v.assign(z[f"v{i}"])
    print(f"resumed after epoch {len(hist)}", flush=True)
t0 = time.time() - elapsed0
done = bad >= CFG["patience"]
for ep in range(len(hist), CFG["max_epochs"]):
    if done:
        break
    h = model.fit(ds(tr, True), epochs=1, class_weight=cw if CFG["class_weight"] else None, verbose=2)
    pv = model.predict(ds(va, False), verbose=0).argmax(1)
    f1v = precision_recall_fscore_support(y[va], pv, average="macro", zero_division=0)[2]
    hist.append(dict(epoch=ep + 1, train_loss=float(h.history["loss"][0]), val_macro_f1=float(f1v), elapsed_s=round(time.time() - t0)))
    print(hist[-1], flush=True)
    if f1v > best_f1:
        best_f1, bad = f1v, 0; model.save_weights(f"{CK}/best.weights.h5")
    else:
        bad += 1
        done = bad >= CFG["patience"]
    model.save_weights(f"{CK}/last.weights.h5")
    np.savez(f"{CK}/opt.npz", **{f"v{i}": v.numpy() for i, v in enumerate(model.optimizer.variables)})
    json.dump(dict(best_f1=best_f1, hist=hist, bad=bad, elapsed=time.time() - t0), open(f"{CK}/state.tmp", "w")); os.replace(f"{CK}/state.tmp", f"{CK}/state.json")
t_train = hist[-1]["elapsed_s"]
model.load_weights(f"{CK}/best.weights.h5")
t0 = time.time(); yp = model.predict(ds(te, False), verbose=0).argmax(1); t_test = time.time() - t0

def metrics(yt, ypp):
    p, r, f, _ = precision_recall_fscore_support(yt, ypp, labels=range(9), zero_division=0)
    P, R, F, _ = precision_recall_fscore_support(yt, ypp, labels=range(9), average="macro", zero_division=0)
    return dict(accuracy=accuracy_score(yt, ypp), macro_p=P, macro_r=R, macro_f1=F,
                per_class={c: dict(p=float(p[i]), r=float(r[i]), f1=float(f[i]), support=int((yt == i).sum())) for i, c in enumerate(CLASSES)},
                confusion=confusion_matrix(yt, ypp, labels=range(9)).tolist())
res = dict(model="BiLSTM_GloVe", split=col, config=dict(CFG, glove="inzva Turkish GloVe, uncased, 300-d", glove_coverage=hit / len(vocab)),
           history=hist, hardware=dict(gpu="none (CPU)", cpu=platform.processor() or platform.machine(), n_cpu=os.cpu_count()),
           train_time_s=round(t_train, 1), test_time_s=round(t_test, 2), n_train=int(tr.sum()), n_test=int(te.sum()), test=metrics(y[te], yp))
if col == "split_orig":
    clean = ~sp.s1_test_has_train_near_dup.values[te]
    res["test_clean"] = metrics(y[te][clean], yp[clean]); res["n_test_clean"] = int(clean.sum())
json.dump(res, open(f"results/runs/{col}__BiLSTM_GloVe.json", "w"), indent=1)
np.save(f"results/runs/{col}__BiLSTM_GloVe_pred.npy", yp.astype(np.int8))
print(f"{col} BiLSTM_GloVe: acc {res['test']['accuracy']:.4f} macro-F1 {res['test']['macro_f1']:.4f} train {t_train/3600:.2f} h", flush=True)
