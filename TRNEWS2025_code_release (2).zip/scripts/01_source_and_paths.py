"""Add the registered source domain and the URL-path section token; summarise publisher sections per class."""
import re, sys, collections
import pyarrow as pa, pyarrow.parquet as pq, pandas as pd, tldextract
P = "data/trnews.parquet"
t = pq.read_table(P)
ext = tldextract.TLDExtract(suffix_list_urls=())
def reg(u):
    e = ext(u or "")
    return f"{e.domain}.{e.suffix}" if e.suffix else e.domain
src = [reg(u) for u in t.column("url").to_pylist()]
if "source" in t.column_names:
    t = t.drop(["source"])
t = t.append_column("source", pa.array(src))
pq.write_table(t, P)

df = t.select(["url", "path", "label", "source"]).to_pandas()
STOP = {"", "haber", "haberler", "news", "tr", "detay", "amp", "video", "galeri", "foto", "fotogaleri", "album", "yazar",
        "yazarlar", "makale", "son-dakika", "sondakika", "gundem", "kategori", "category", "arsiv", "index.php", "www",
        "mobil", "m", "turkce", "turkish", "content", "story", "article", "articles", "post", "posts", "page", "sayfa"}
def section(path):
    segs = [s for s in path.split("/") if s]
    for s in segs[:-1] if len(segs) > 1 else []:
        s2 = re.sub(r"\.(html?|php|aspx?)$", "", s)
        if s2 in STOP or re.fullmatch(r"[\d\-]+", s2) or len(s2) > 30:
            continue
        return s2
    return ""
df["section"] = [section(p) for p in df.path]
df[["section"]].to_parquet("data/sections.parquet")
has = df.section != ""
print(f"articles with a URL section token: {has.mean():.3f}")
top = (df[has].groupby(["section", "label"]).size().rename("n").reset_index())
tot = top.groupby("section").n.sum().rename("total")
top = top.merge(tot, on="section")
top["share"] = top.n / top.total
dom = top.sort_values("n", ascending=False).drop_duplicates("section").sort_values("total", ascending=False)
dom.head(60).to_csv("results/url_sections_top60.csv", index=False)
print(dom.head(60).to_string(index=False))
