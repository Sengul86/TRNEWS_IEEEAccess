"""Figures for the revised manuscript: confusion matrix of the linear SVM on S1 and learning curves of the GPU models."""
import json, os
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

OUT = "manuscript/figures"; os.makedirs(OUT, exist_ok=True)
EN = ["Magazine", "Politics", "Sports", "Arts–Culture", "Health", "Finance–Econ.", "Science–Tech.", "Tourism", "Environment"]
plt.rcParams.update({"font.size": 9})

r = json.load(open("results/runs/split_orig__LinearSVM_tfidf.json"))
cm = np.array(r["test"]["confusion"], float); cmn = cm / cm.sum(1, keepdims=True)
fig, ax = plt.subplots(figsize=(6.2, 5.2))
im = ax.imshow(cmn, cmap="Blues", vmin=0, vmax=1)
for i in range(9):
    for j in range(9):
        ax.text(j, i, f"{100*cmn[i,j]:.1f}", ha="center", va="center", fontsize=7, color="white" if cmn[i, j] > 0.5 else "black")
ax.set_xticks(range(9), EN, rotation=45, ha="right"); ax.set_yticks(range(9), EN)
ax.set_xlabel("Predicted class"); ax.set_ylabel("True class")
fig.colorbar(im, fraction=0.046, pad=0.04, label="Row-normalized share")
plt.tight_layout(); plt.savefig(f"{OUT}/cm_svm_s1.pdf"); plt.savefig(f"{OUT}/cm_svm_s1.png", dpi=300); plt.close()

fig, axes = plt.subplots(1, 2, figsize=(9, 3.2))
for ax, (m, lbl, key) in zip(axes, [("BiLSTM_GloVe", "BiLSTM–GloVe", "epoch"), ("BERTurk", "BERTurk", "epoch")]):
    p = f"results/runs/split_orig__{m}.json"
    if os.path.exists(p):
        h = json.load(open(p))["history"]
        ax.plot([x[key] for x in h], [100 * x["val_macro_f1"] for x in h], "o-")
        ax.set_xlabel("Epoch"); ax.set_ylabel("Validation macro-F1 (%)")
    else:
        ax.text(0.5, 0.5, "pending (GPU run)", ha="center", va="center", color="red", transform=ax.transAxes)
    ax.set_title(lbl); ax.grid(alpha=0.3)
plt.tight_layout(); plt.savefig(f"{OUT}/learning_curves.pdf"); plt.savefig(f"{OUT}/learning_curves.png", dpi=300); plt.close()
print("figures written")
