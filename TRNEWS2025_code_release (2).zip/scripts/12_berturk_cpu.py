"""Budget-limited BERTurk fine-tuning on CPU (S1).

Because full fine-tuning on 641k articles is not feasible without a GPU (about 50 h per epoch on the 4-core CPU used
here), BERTurk is fine-tuned on a stratified random subset of the S1 training partition and evaluated on the complete
S1 test set. Settings: dbmdz/bert-base-turkish-uncased, Turkish lowercasing with diacritics preserved
(strip_accents=False), max. 128 tokens, AdamW lr 3e-5, weight decay 0.01, batch 16, one epoch, linear schedule with 6%
warm-up; the validation macro-F1 on a stratified 4,000-article validation subset is evaluated four times and the best
checkpoint is used for testing.

Usage: python 12_berturk_cpu.py <model_dir> <n_train> [split_column]
"""
import json, os, sys, time, platform
import numpy as np, pandas as pd, pyarrow.parquet as pq, torch
from torch.utils.data import DataLoader
from transformers import AutoTokenizer, AutoModelForSequenceClassification, get_linear_schedule_with_warmup
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix

MODEL, NTR = sys.argv[1], int(sys.argv[2]); col = sys.argv[3] if len(sys.argv) > 3 else "split_orig"
CFG = dict(model="dbmdz/bert-base-turkish-uncased", n_train_subset=NTR, max_len=128, lr=3e-5, weight_decay=0.01, batch=16,
           epochs=1, warmup=0.06, n_val_subset=4000, evals_per_epoch=4)
CLASSES = ["Magazin", "Siyaset", "Spor", "Kültür-Sanat", "Sağlık", "Finans-Ekonomi", "Bilim-Teknoloji", "Turizm", "Çevre"]
torch.manual_seed(42); torch.set_num_threads(os.cpu_count())

text = pq.read_table("data/trnews.parquet", columns=["text"]).column("text").to_pylist()
sp = pd.read_parquet("data/splits.parquet")
y = sp.label.map({c: i for i, c in enumerate(CLASSES)}).values
low = lambda t: t.replace("I", "ı").replace("İ", "i").lower()
tr_all = np.flatnonzero(sp[col].values == "train"); va_all = np.flatnonzero(sp[col].values == "validation")
te = np.flatnonzero(sp[col].values == "test")
tr, _ = train_test_split(tr_all, train_size=NTR, stratify=y[tr_all], random_state=42)
va, _ = train_test_split(va_all, train_size=CFG["n_val_subset"], stratify=y[va_all], random_state=42)

tok = AutoTokenizer.from_pretrained(MODEL, strip_accents=False, do_lower_case=False)
model = AutoModelForSequenceClassification.from_pretrained(MODEL, num_labels=9)
def collate(idx):
    enc = tok([low(text[i]) for i in idx], truncation=True, max_length=CFG["max_len"], padding=True, return_tensors="pt")
    enc["labels"] = torch.tensor(y[idx]); return enc
def predict(idx):
    model.eval(); out = []
    with torch.no_grad():
        for b in DataLoader(list(idx), batch_size=64, collate_fn=collate):
            b.pop("labels"); out.append(model(**b).logits.argmax(-1).numpy())
    model.train(); return np.concatenate(out)

# Resumable training: the shuffled order is fixed by the seed, and model/optimizer/scheduler state is checkpointed
# every 200 steps (the cloud container may restart during the multi-hour CPU run).
CK = f"ckpt/berturk_{col}"; os.makedirs(CK, exist_ok=True)
order = torch.randperm(len(tr), generator=torch.Generator().manual_seed(42)).numpy()
batches = [tr[order[i:i + CFG["batch"]]] for i in range(0, len(tr), CFG["batch"])]
opt = torch.optim.AdamW(model.parameters(), lr=CFG["lr"], weight_decay=CFG["weight_decay"])
steps = len(batches) * CFG["epochs"]; sch = get_linear_schedule_with_warmup(opt, int(CFG["warmup"] * steps), steps)
eval_every = max(1, len(batches) // CFG["evals_per_epoch"])
best_f1, hist, step, elapsed0 = -1.0, [], 0, 0.0
def save(path, obj):
    torch.save(obj, path + ".tmp"); os.replace(path + ".tmp", path)
if os.path.exists(f"{CK}/state.pt"):
    st = torch.load(f"{CK}/state.pt", weights_only=False)
    model.load_state_dict(st["model"]); opt.load_state_dict(st["opt"]); sch.load_state_dict(st["sch"])
    torch.set_rng_state(st["rng"]); best_f1, hist, step, elapsed0 = st["best_f1"], st["hist"], st["step"], st["elapsed"]
    print(f"resumed at step {step}", flush=True)
t0 = time.time() - elapsed0
model.train()
while step < steps:
    b = collate(batches[step % len(batches)])
    loss = model(**b).loss; loss.backward()
    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0); opt.step(); sch.step(); opt.zero_grad(); step += 1
    if step % 200 == 0:
        print(f"step {step}/{steps} loss {loss.item():.3f} {time.time()-t0:.0f}s", flush=True)
    if step % eval_every == 0 or step == steps:
        pv = predict(va); f1v = precision_recall_fscore_support(y[va], pv, average="macro", zero_division=0)[2]
        hist.append(dict(step=step, epoch=step / len(batches), train_loss=loss.item(), val_macro_f1=float(f1v), elapsed_s=round(time.time() - t0)))
        print(hist[-1], flush=True)
        if f1v > best_f1:
            best_f1 = f1v; save(f"{CK}/best.pt", model.state_dict())
    if step % 200 == 0 or step == steps:
        save(f"{CK}/state.pt", dict(model=model.state_dict(), opt=opt.state_dict(), sch=sch.state_dict(), rng=torch.get_rng_state(),
                                    best_f1=best_f1, hist=hist, step=step, elapsed=time.time() - t0))
t_train = time.time() - t0
model.load_state_dict(torch.load(f"{CK}/best.pt"))
# test prediction in chunks, each saved, so a restart does not repeat finished chunks
parts, t_test = [], 0.0
for k, i in enumerate(range(0, len(te), 8192)):
    f = f"{CK}/test_{k:03d}.npz"
    if not os.path.exists(f):
        t1 = time.time(); p = predict(te[i:i + 8192]); np.savez(f, p=p, t=time.time() - t1)
        print(f"test chunk {k} done", flush=True)
    z = np.load(f); parts.append(z["p"]); t_test += float(z["t"])
yp = np.concatenate(parts)

def metrics(yt, ypp):
    p, r, f, _ = precision_recall_fscore_support(yt, ypp, labels=range(9), zero_division=0)
    P, R, F, _ = precision_recall_fscore_support(yt, ypp, labels=range(9), average="macro", zero_division=0)
    return dict(accuracy=accuracy_score(yt, ypp), macro_p=P, macro_r=R, macro_f1=F,
                per_class={c: dict(p=float(p[i]), r=float(r[i]), f1=float(f[i]), support=int((yt == i).sum())) for i, c in enumerate(CLASSES)},
                confusion=confusion_matrix(yt, ypp, labels=range(9)).tolist())
res = dict(model="BERTurk", split=col, config=CFG, history=hist,
           hardware=dict(gpu="none (CPU)", cpu=platform.processor() or platform.machine(), n_cpu=os.cpu_count()),
           train_time_s=round(t_train, 1), test_time_s=round(t_test, 2), n_train=int(len(tr)), n_test=int(len(te)), test=metrics(y[te], yp))
if col == "split_orig":
    clean = ~sp.s1_test_has_train_near_dup.values[te]
    res["test_clean"] = metrics(y[te][clean], yp[clean]); res["n_test_clean"] = int(clean.sum())
json.dump(res, open(f"results/runs/{col}__BERTurk.json", "w"), indent=1)
np.save(f"results/runs/{col}__BERTurk_pred.npy", yp.astype(np.int8))
print(f"{col} BERTurk: acc {res['test']['accuracy']:.4f} macro-F1 {res['test']['macro_f1']:.4f} train {t_train/3600:.2f} h test {t_test/3600:.2f} h", flush=True)
