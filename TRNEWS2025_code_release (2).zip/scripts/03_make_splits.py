"""Create the split assignment files used in the revised experiments.

S1 original      : the published 80/10/10 stratified article-level split (as distributed).
S2 dedup_grouped : 80/10/10 split in which every near-duplicate cluster (MinHash, Jaccard >= 0.8) is kept in a
                   single partition (StratifiedGroupKFold on clusters, 10 folds: 8 train / 1 validation / 1 test).
S3 source_heldout: 80/10/10 split in which every source domain belongs to a single partition (StratifiedGroupKFold on
                   registered domains); test and validation publishers are never seen during training.
Also writes the 'clean' test subset of S1 (test articles without a near-duplicate in S1-train).
"""
import json
import numpy as np, pandas as pd, pyarrow.parquet as pq
from sklearn.model_selection import StratifiedGroupKFold

df = pq.read_table("data/trnews.parquet", columns=["id", "label", "source", "split_orig"]).to_pandas()
cl = pd.read_parquet("data/near_dup_clusters.parquet")
assert (cl.id.values == df.id.values).all()
df["cluster"] = cl.cluster.values; df["cluster_size"] = cl.cluster_size.values

def grouped_split(groups, seed=42):
    sgkf = StratifiedGroupKFold(n_splits=10, shuffle=True, random_state=seed)
    fold = np.empty(len(df), int)
    for k, (_, te) in enumerate(sgkf.split(np.zeros(len(df)), df.label.values, groups)):
        fold[te] = k
    return np.where(fold == 0, "test", np.where(fold == 1, "validation", "train"))

df["split_dedup_grouped"] = grouped_split(df.cluster.values)
df["split_source_heldout"] = grouped_split(df.source.values)

train_clusters = set(df.cluster[(df.split_orig == "train") & (df.cluster_size > 1)])
df["s1_test_has_train_near_dup"] = (df.split_orig == "test") & (df.cluster_size > 1) & df.cluster.isin(train_clusters)

out = df[["id", "label", "source", "cluster", "cluster_size", "split_orig", "split_dedup_grouped", "split_source_heldout",
          "s1_test_has_train_near_dup"]]
out.to_csv("results/trnews2025_split_assignments.csv.gz", index=False, compression="gzip")
out.to_parquet("data/splits.parquet", index=False)

rep = {}
for col in ["split_orig", "split_dedup_grouped", "split_source_heldout"]:
    ct = pd.crosstab(df.label, df[col])
    rep[col] = dict(sizes=df[col].value_counts().to_dict(),
                    min_class_share_in_test=float((ct["test"] / ct.sum(1)).min()),
                    max_class_share_in_test=float((ct["test"] / ct.sum(1)).max()))
    # leakage: test articles whose near-duplicate cluster also has a train member
    trc = set(df.cluster[(df[col] == "train") & (df.cluster_size > 1)])
    te = df[df[col] == "test"]
    rep[col]["test_with_train_near_dup"] = int(((te.cluster_size > 1) & te.cluster.isin(trc)).sum())
    trs = set(df.source[df[col] == "train"])
    rep[col]["test_articles_from_train_sources"] = float(te.source.isin(trs).mean())
    rep[col]["n_test_sources"] = int(te.source.nunique())
    print(col, ct.to_dict(orient="dict")["test"])
rep["s1_clean_test_size"] = int(((df.split_orig == "test") & ~df.s1_test_has_train_near_dup).sum())
json.dump(rep, open("results/splits_summary.json", "w"), indent=2)
print(json.dumps(rep, indent=2))
