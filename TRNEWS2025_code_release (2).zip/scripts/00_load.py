"""Load the three published CSV splits, add domain / URL-path / length fields and save one parquet file.

Usage: python 00_load.py <dir with trnews_{train,validation,test}.csv> <out.parquet>
"""
import re, sys
from urllib.parse import urlparse
import pyarrow as pa, pyarrow.csv as pcsv, pyarrow.compute as pc, pyarrow.parquet as pq

src, out = sys.argv[1], sys.argv[2]
ren = {"ID": "id", "Erişim Tarihi": "access_time", "URL": "url", "Haber Gövdesi": "text", "Sınıf": "label"}
tables = []
for s in ["train", "validation", "test"]:
    t = pcsv.read_csv(f"{src}/trnews_{s}.csv", parse_options=pcsv.ParseOptions(newlines_in_values=True),
                      convert_options=pcsv.ConvertOptions(column_types={c: pa.string() for c in ren}))
    t = t.rename_columns([ren[c.lstrip("﻿")] for c in t.column_names])
    t = t.append_column("split_orig", pa.array([s] * t.num_rows))
    tables.append(t)
t = pa.concat_tables(tables)

def domain(u):
    try:
        h = urlparse(u).netloc.lower()
    except Exception:
        return ""
    return re.sub(r"^(www\d?|m|mobil|amp)\.", "", h.split(":")[0])

urls = t.column("url").to_pylist()
t = t.append_column("domain", pa.array([domain(u or "") for u in urls]))
t = t.append_column("path", pa.array([(urlparse(u).path.lower() if u and u.startswith("http") else "") for u in urls]))
t = t.append_column("n_words", pc.count_substring_regex(t.column("text"), r"\S+"))
pq.write_table(t, out)
print(t.num_rows, "rows;", len(set(t.column("domain").to_pylist())), "domains")
print(t.group_by("split_orig").aggregate([("id", "count")]))
