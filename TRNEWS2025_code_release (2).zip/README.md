# TRNEWS-2025 – evaluation splits, analyses and baselines

Code and supplementary data for the paper *TRNEWS-2025: A Large-Scale, Labeled Turkish News Dataset for Text
Classification and NLP Research*. The dataset itself (801,589 articles) is available from IEEE DataPort,
https://doi.org/10.21227/vasv-dj22 (files `trnews_train.csv`, `trnews_validation.csv`, `trnews_test.csv`).

## Released files (`release/`)

| File | Content |
|---|---|
| `trnews2025_split_assignments.csv.gz` | One row per article: `id`, `label`, `source` (registered domain), near-duplicate `cluster` and `cluster_size` (MinHash, Jaccard ≥ 0.8), and the partition in the three splits `split_orig` (S1, published), `split_dedup_grouped` (S2), `split_source_heldout` (S3); `s1_test_has_train_near_dup` marks the S1 test articles that have a near-duplicate in S1-train |
| `section_mapping_table.csv` | Publisher URL section tokens mapped to the nine classes, with frequencies and label agreement |
| `url_section_vs_label_crosstab.csv` | Class implied by the URL section versus dataset label |
| `label_audit_sheet_for_annotators.csv` | Stratified audit sample (900 articles) for independent re-annotation |
| `near_dup_summary_t60/80/90.json` | Near-duplicate statistics at three thresholds |

## Pipeline (`scripts/`)

| Step | Script | Notes |
|---|---|---|
| 0 | `00_load.py <csv dir> data/trnews.parquet` | merges the three CSV files, adds domain / URL path / length |
| 1 | `01_source_and_paths.py` | registered source domain (Public Suffix List via `tldextract`) |
| 2 | `02_near_duplicates.py [threshold]` | MinHash-LSH, word 5-gram shingles, 128 permutations, 32 bands × 4 rows |
| 3 | `03_make_splits.py` | S2 and S3 with `StratifiedGroupKFold(10, shuffle=True, random_state=42)` |
| 4 | `04_baselines.py <split> [mnb,svm,fasttext]` | CPU baselines; `04b_source_folds.py <k>` additional source-held-out folds |
| 5 | `05_cross_dataset.py <ttc4900.parquet>` | controlled comparison with TTC-4900 (Hugging Face `savasy/ttc4900`) |
| 6 | `06_label_audit.py`, `07_audit_agreement.py` | URL-section agreement, audit sample, annotator agreement |
| 8–10 | `08_tables.py`, `09_leak_effect.py`, `10_figures.py` | LaTeX tables, leakage effect, figures |
| 11 | `11_bilstm_cpu.py <split> <glove vectors.txt>` | BiLSTM–GloVe (inzva Turkish GloVe, 300-d); resumable per epoch |
| 12 | `12_berturk_cpu.py <model dir> 50000 split_orig` | budget-limited BERTurk fine-tuning (50k articles, 1 epoch, 128 tokens); resumable |
| – | `run_queue.sh` | runs 11 (S1–S3) and 12 in sequence, skipping finished runs |
| optional | `TRNEWS_GPU_BiLSTM_BERT.ipynb` | the same models for a single GPU (Colab) |

Python 3.12; numpy, pandas, pyarrow, scikit-learn 1.9, fasttext-wheel, own NumPy MinHash implementation,
tldextract; TensorFlow 2.19 (BiLSTM) and PyTorch/transformers (BERTurk). All reported experiments, including the neural models, were run
on the same 4-core Intel Xeon 2.1 GHz CPU with 16 GB RAM; per-run results, histories and timings are in `results/runs/`. Random seed 42 throughout.

## License

Code: MIT. Labels, split assignments and metadata: as stated on the IEEE DataPort record. The copyright of the news
texts remains with the original publishers.
